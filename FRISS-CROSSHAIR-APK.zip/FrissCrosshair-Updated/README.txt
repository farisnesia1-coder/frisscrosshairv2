FRISS CROSSHAIR v1.1 — Android source project

Features: custom red reticle image overlay, fixed at screen center, ON/OFF controls, size slider, polished dark blue/red interface, no ads, no root, no network permission.

Build with GitHub Actions workflow in .github/workflows/build-apk.yml. This is source code, not a compiled APK. Android overlay permission is required.
